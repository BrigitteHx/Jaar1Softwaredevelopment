// (!(inputDrank in drankMenu))
