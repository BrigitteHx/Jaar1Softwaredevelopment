<h1>Onkunde</h1>

<form action="" method="post">
    <label>Wat zou je graag willen kunnen?</label>
    <input type="text" name="vraag1" required><br><br>

    <label>Met welke persoon kun je goed opschieten?</label>
    <input type="text" name="vraag2" required><br><br>

    <label>Wat is je favoriete getal?</label>
    <input type="text" name="vraag3" required><br><br>

    <label>Wat heb je altijd bij je als je op vakantie gaat?</label>
    <input type="text" name="vraag4" required><br><br>

    <label>Wat is je beste persoonlijke eigenschap?</label>
    <input type="text" name="vraag5" required><br><br>

    <label>Wat is je slechtste persoonlijke eigenschap?</label>
    <input type="text" name="vraag6" required><br><br>

    <label>Wat is het ergste dat je kan overkomen?</label>
    <input type="text" name="vraag7" required><br><br>

    <input type="submit" value="Verzenden">
</form>
