<h1>Er heerst paniek...</h1>

<form action="" method="post">
    <label>Welk dier zou je nooit als huisdier willen?</label>
    <input type="text" name="vraag1" required><br><br>

    <label>Wie is de belangrijkste persoon in je leven?</label>
    <input type="text" name="vraag2" required><br><br>

    <label>In welk land zou je graag willen wonen?</label>
    <input type="text" name="vraag3" required><br><br>

    <label>Wat doe je als je je verveelt?</label>
    <input type="text" name="vraag4" required><br><br>

    <label>Met welk speelgoed speelde je als kind het meest?</label>
    <input type="text" name="vraag5" required><br><br>

    <label>Bij welke docent spijbel je het liefst?</label>
    <input type="text" name="vraag6" required><br><br>

    <label>Als je 100.000 euro had, wat zou je dan kopen?</label>
    <input type="text" name="vraag7" required><br><br>

    <label>Wat is je favoriete bezigheid?</label>
    <input type="text" name="vraag8" required><br><br>

    <input type="submit" value="Verzenden">
</form>
